package com.niccode.desarrollounaapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button Siguiente = (Button) findViewById(R.id.Siguiente);

        final EditText etName         = (EditText) findViewById(R.id.tiNombreCompleto);
        final EditText etFecha       = (EditText)findViewById(R.id.Calendario);
        final EditText etTelefono    = (EditText)findViewById(R.id.tiTelefono);
        final EditText etEmail       = (EditText)findViewById(R.id.tiEmail);
        final EditText etDescripcion = (EditText) findViewById(R.id.tiDescripcionContacto);


        MaterialDatePicker.Builder<Long> builder = MaterialDatePicker.Builder.datePicker();
        builder.setTitleText(getResources().getString(R.string.date1));

        final MaterialDatePicker<Long> materialDatePicker = builder.build();

        etFecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDatePicker.show(getSupportFragmentManager(), "DATE_PICKER");

            }
        });

        materialDatePicker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener() {
            @Override
            public void onPositiveButtonClick(Object selection) {
                etFecha.setText(materialDatePicker.getHeaderText());
            }
        });


        Siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, Confirmar_Datos.class);

                intent.putExtra(getResources().getString(R.string.pname), etName.getText().toString());
                intent.putExtra(getResources().getString(R.string.pdate),  etFecha.getText().toString());
                intent.putExtra(getResources().getString(R.string.ptelefono), etTelefono.getText().toString());
                intent.putExtra(getResources().getString(R.string.pemail),  etEmail.getText().toString());
                intent.putExtra(getResources().getString(R.string.pDescripcion),  etDescripcion.getText().toString());

                startActivity(intent);
                finish();


            }
        });


    }
}