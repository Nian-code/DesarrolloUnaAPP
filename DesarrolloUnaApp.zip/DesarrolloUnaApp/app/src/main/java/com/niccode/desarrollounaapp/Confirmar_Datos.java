package com.niccode.desarrollounaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Confirmar_Datos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.confirmar_datos);

        Button Regresar = (Button) findViewById(R.id.regresar);

        Bundle parametros = getIntent().getExtras();
        assert parametros != null;
        final String str_nombre = parametros.getString(getResources().getString(R.string.pname));
        final String str_fecha = parametros.getString(getResources().getString(R.string.pdate));
        final String str_telefono = parametros.getString(getResources().getString(R.string.ptelefono));
        final String str_email = parametros.getString(getResources().getString(R.string.pemail));
        final String str_descripcion = parametros.getString(getResources().getString(R.string.pDescripcion));


        final TextView tvnombre = findViewById(R.id.Nombre_Completo_Confirmado);
        final TextView tvfecha  = findViewById(R.id.fecha_de_nacimiento_Confirmado);
        final TextView tvTelefono  = findViewById(R.id.tel_Confirmado);
        final TextView tvEmail = findViewById(R.id.mail_Confirmado);
        final TextView tvDescripcion = findViewById(R.id.Descripcion_Confirmado);

        tvnombre.setText(str_nombre);
        tvfecha.setText("Fecha de nacimiento : " + str_fecha);
        tvTelefono.setText("Número Télefónico : " + str_telefono);
        tvEmail.setText("Email : " + str_email);
        tvDescripcion.setText("Descripción : " + str_descripcion);



        Regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 finish();
            }
        });


        }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK){
            Intent intent = new Intent(Confirmar_Datos.this, MainActivity.class);
            startActivity(intent);
        }
        return super.onKeyDown(keyCode, event);

    }
    }
